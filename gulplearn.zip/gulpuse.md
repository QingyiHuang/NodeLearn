###gulp本地安装插件###

	cnpm install --save-dev;

例如安装gulp-less

	cnpm install gulp-less --save-dev；

> 为了能正常使用，我们还得本地安装

   `gulp：cnpm install gulp --save-dev；`

> PS：细心的你可能会发现，我们全局安装了gulp，项目也安装了gulp，全局安装gulp是为了执行gulp任务，本地安装gulp则是为了调用gulp插件的功能
###新建package.json###
用 cnpm init 快速构建package.json
###新建gulpfile.js文件###

> gulpfile.js是gulp项目的配置文件，是位于项目根目录的普通js文件
> 
> //实例通过代码会附带上
> 
说明：命令提示符执行gulp 任务名称；

>编译less：命令提示符执行gulp testLess；
>
>当执行gulp default或gulp将会调用default任务里的所有任务
>
>[‘testLess’,’elseTask’]。

详情代码附上