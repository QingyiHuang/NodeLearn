//导入工具包
var gulp = require('gulp'),
	less = require('gulp-less');

//定义一个testLess任务
gulp.task('testLess',function(){
	gulp.src('./index.less')
		.pipe(less())//该任务调用模块
		.pipe(gulp.dest('./'));//会在./目录生成css
});

gulp.task('default',['testLess','elseTask'])
//定义默认任务 elseTask为其他任务，该示例没有定义elseTask任务
 
//gulp.task(name[, deps], fn) 定义任务  name：任务名称 deps：依赖任务名称 fn：回调函数
//gulp.src(globs[, options]) 执行任务处理的文件  globs：处理的文件路径(字符串或者字符串数组) 
//gulp.dest(path[, options]) 处理完后文件生成路径